package com.example.carracegame

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.carracegame.R.id.splashLayout

class SplashActivity : AppCompatActivity() {

    private val SPLASH_TIME_OUT: Long = 3000 // 3 seconds
    private var splashHandler: Handler? = null
    private var splashRunnable: Runnable? = null
    private var shouldNavigate: Boolean = true

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Initialize the Handler and Runnable for delayed navigation
        splashHandler = Handler()
        splashRunnable = Runnable {
            if (shouldNavigate) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }

        // Start the splash timeout
        splashHandler?.postDelayed(splashRunnable!!, SPLASH_TIME_OUT)

        // Add click listener to the layout
        findViewById<View>(splashLayout).setOnClickListener {
            shouldNavigate = true
            // Cancel the delayed navigation
            splashHandler?.removeCallbacks(splashRunnable!!)
            // Navigate to MainActivity immediately
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Remove the callbacks to prevent memory leaks
        splashHandler?.removeCallbacks(splashRunnable!!)
    }
}
